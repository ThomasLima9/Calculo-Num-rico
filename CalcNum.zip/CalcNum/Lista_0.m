#LISTA 0
clc
clear all

#EXERCICIO 1----------------
% exemplo a = 1:1:50 primeiro termo começa no primeiro : espaçamento : final
#for i = 1:50;
#  disp(i)
#endfor

#EXERCICIO 2----------------
#for i = 2:2:100
#  disp(i)
#endfor

#EXERCICIO 3--------------

#n = input('Digite um número de 1 a 10: ');
#if n < 1 || n > 10
#    fprintf('Numero inválido\n')

#  else
#    fprintf('Tabuada do %d\n', n)

#    for i = 1:10
#      conta = n * i;
#      fprintf('%d X %d = %d\n', n , i ,conta);
#    end

#end

#EXERCICIO 4-------------

#contador_pares = 0
#contador_impares = 0

#for i = 1:10
#  n = input('Digite um número: ');

#  if mod(n,2) == 0
#    contador_pares = contador_pares + 1;

#  else
#    contador_impares = contador_impares + 1;

#  endif

#endfor

#fprintf('O numero de pares é %d\n', contador_pares);
#fprintf('O numero de impares é %d\n', contador_impares);

#EXERCICIO 5------------

#conta_fora = 0
#conta_dentro = 0

#for i = 1:10
#  n = input('Digite um número: ');

#  if n >= 0 && n <= 10
#    conta_dentro = conta_dentro + 1;

#  else
#    conta_fora = conta_fora + 1;

#  endif

#endfor

#fprintf('Tem %d dentro do intervalo\n' , conta_dentro)
#fprintf('Tem %d fora do intervalo\n' , conta_fora)

#EXERCICIO 6----------

#for i = 1:11
#  fprintf(' %d - Eu adoro programar\n' , i)

#endfor

#EXERCICIO 7------------

#raiz = input('Digite um número para calcular sua raiz: ');
#conta = sqrt(raiz);
#if raiz < 0
#  fprintf('A raiz quadrada e imaginária')

#else
# fprintf('O resultado é %d\n', conta)

#endif

#EXERCICIO 8 --------------

#lado1 = input('Digite o comprimento do lado1: ');
#lado2 = input('Digite o comprimento do lado2: ');
#lado3 = input('Digite o comprimento do lado3: ');

#if lado1 == lado2 && lado2 == lado3
#  fprintf('O trinagulo e equilatero')

#elseif lado1 == lado2 || lado2 == lado3 || lado1 == lado3
#  fprintf('O tringulo é isosceles')

#else
#  fprintf('O trinagulo e escaleno')

#endif

#EXERCICIO 9 --------------


#somatorio = 0;

#for k = 1:20;
#  somatorio = somatorio + k^k;

#endfor

#fprintf('Resultado é: %u\n', somatorio);

#EXERCICIO 12

#a = input('Digite a altura (h): ');
#b = input('Digite a base (b): ');

#area = area_triag(a,b);


#fprintf('A área do triângulo é: %d \n', area);

# podese usar o lambda por exemplo area = @(a,b) b*h/2
#EXERCICIO 18

#n1 = 1;
#n2 = 1;

#while true

#  n = input('Digite o n-ésimo termo:');

#  if  n < 1
#    disp('Numero inválido')
#    continue;

#  elseif n == 1
#    fprintf('O n-ésimo termo é: %d\n', n1);
#    break;

#  else
#    fib = [n1,n2];

#    for i = 3:n
#      soma = n1 + n2;
#      fib = [fib , soma];
#      n1 = n2;
#      n2 = soma;

#    end
#   fprintf('O Valor n-ésimo termo é: %d\n', fib(n));
#   disp('A sequência de Fibonacci até o n-ésimo termo é:');
#   disp(fib);
#   break;
# end
#end

#EX 18 exemplo professor


#n = input('Digite o nésimo termo:');
#F(1) = 1;
#F(2) = 1;

#for i = 3:n
#  F(i) = F(i-1) + F(i-2);
#end

#disp(F)





#EXERCICIO 13


#EXERCICIO 30

#n = input('Digite a n-ésimo termo: ');
#h = 0;

#for i = 1:n;

#  h = h + 1/i;

#endfor

#fprintf('Valor de H é : %d', h);


#EXERCICIO 36

#function fn = seq(n)

#  if mod(n,2) == 1
#    fn = 1;

#  else
#    fn = 2/(n + 2);

#  end

#end

#exercicio professor
%{
lista = [];
while length(lista) < 100
  for i = 1:1000
    if isprime(i);
      lista = [lista,i];
    endif

  endfor

end

fprintf('%d\n', lista)
%}

%{
v = []
n = 2
countador = 1
while count <= 100
  if isprime(n) == 1
    v(count) = n
    count += 1
   endif
  n += 1
endwhile
%}
contador = 0;
i = 0;
p = [];
while contador < 100;

  i = i + 1;

  if isprime(i);
    contador = contador + 1;
    p = [p i];

  endif

end

disp('Os 100 primeiros números primos são:');
disp(p);














