function area = area_triag(a,b)
  area = a*b;
  perimetro = 2*a + 2*b

endfunction



