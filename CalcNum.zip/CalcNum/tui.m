n = 1:1:100;

for i = 1:length(n)
  fn(i) = seq(n(i));

end

plot(n,fn,'d','color','r')


